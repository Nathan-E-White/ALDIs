package com.cuc.app.scrape;

public class Application {
    public static void main (String[] args) {

    }
}


