package com.cuc.app.scrape.pages;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

class LoginPageTest {

    @BeforeEach
    void setUp () {
    }

    @AfterEach
    void tearDown () {
    }
}
