package com.cuc.app.scrape.pages;

public record XPathString(String xpath) {
}
